Word Compare inputs for Docxodus #1187
https://github.com/JSv4/Docxodus/issues/1187

These six DOCX files were generated from the issue's make_fixtures.py
without changing the generator. The generator and SHA-256 hashes are included.

In desktop Word:
1. Extract this ZIP to a folder.
2. Choose Review > Compare > Compare (compare two versions of a document).
3. Select the left file as Original and the matching right file as Revised.
   Include formatting in the comparison and show changes in a new document.
4. Save that new comparison document, keeping its tracked changes, as:
   referenced_word_compare.docx
   reverse_word_compare.docx
   unreferenced_word_compare.docx
5. Attach all three comparison outputs to issue #1187. Please also record
   your Word version/build, operating system, comparison options, and any
   warnings or repair prompts. A screenshot of the expanded Compare options
   is useful.

Pairs:
- referenced_left.docx / referenced_right.docx
  Original: paragraph style DocID (8pt), used by "Document reference 123".
  Revised: character style DocID (bold/red), used by an inserted run.
- reverse_left.docx / reverse_right.docx
  Original: character style DocID, used by a kept run.
  Revised: paragraph style DocID, used by an inserted paragraph.
- unreferenced_left.docx / unreferenced_right.docx
  Control: paragraph/character style ID collision, with no revised content
  referencing the revised DocID style.

Please compare the original files directly; do not rename styles or resave
the inputs first. Save the comparison outputs before accepting/rejecting
changes. PDF exports or copies of the inputs cannot answer this question.

The returned DOCX files let us inspect word/styles.xml and word/document.xml
to determine which styles Word drops, renames, or merges; the style references
used by the inserted content; and any changes to style display names.
