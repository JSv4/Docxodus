"""Fixture pairs for checking, in Word's compare, what happens when the original and revised documents use one
style id for styles of different types (issue #1184).

Writes into the directory given as argv[1] (default: this script's directory):
  unreferenced_left.docx / unreferenced_right.docx  - the issue's pair: nothing in the revised body uses the
                                                       revised character style DocID (Word: dropped).
  referenced_left.docx   / referenced_right.docx    - the revised document INSERTS a paragraph whose run uses the
                                                       character style DocID; the original's DocID is a paragraph
                                                       style still used by a kept paragraph. (Word: unverified.)
  reverse_left.docx      / reverse_right.docx       - the mirror: the original's DocID is a character style used
                                                       by a kept run; the revised document inserts a paragraph
                                                       using a paragraph style DocID. (Word: unverified.)
"""
import os
import sys
import zipfile

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
CT = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
      '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
      '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/></Types>')
RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
DOCRELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
           '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
           '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/></Relationships>')
SETTINGS = f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings {W}/>'
SECT = ('<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" '
        'w:left="1440" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>')
NORMAL = '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>'
PARA_DOCID = ('<w:style w:type="paragraph" w:customStyle="1" w:styleId="DocID"><w:name w:val="DocID"/>'
              '<w:basedOn w:val="Normal"/><w:rPr><w:sz w:val="16"/></w:rPr></w:style>')
CHAR_DOCID = ('<w:style w:type="character" w:customStyle="1" w:styleId="DocID"><w:name w:val="DocID"/>'
              '<w:rPr><w:b/><w:color w:val="C00000"/></w:rPr></w:style>')


def p(text, ppr=""):
    return f'<w:p>{ppr}<w:r><w:t xml:space="preserve">{text}</w:t></w:r></w:p>'


def styled_run_p(style_id, text):
    return f'<w:p><w:r><w:rPr><w:rStyle w:val="{style_id}"/></w:rPr><w:t xml:space="preserve">{text}</w:t></w:r></w:p>'


def write(name, body, styles):
    with zipfile.ZipFile(os.path.join(OUT, name), "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", CT)
        z.writestr("_rels/.rels", RELS)
        z.writestr("word/_rels/document.xml.rels", DOCRELS)
        z.writestr("word/settings.xml", SETTINGS)
        z.writestr("word/styles.xml",
                   f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles {W}>{NORMAL}{styles}</w:styles>')
        z.writestr("word/document.xml",
                   f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {W}><w:body>{body}{SECT}</w:body></w:document>')


DOCID_PARA = p("Document reference 123", '<w:pPr><w:pStyle w:val="DocID"/></w:pPr>')

write("unreferenced_left.docx", p("The original paragraph."), PARA_DOCID)
write("unreferenced_right.docx", p("The revised paragraph."), CHAR_DOCID)

write("referenced_left.docx", p("The original paragraph.") + DOCID_PARA, PARA_DOCID)
write("referenced_right.docx",
      p("The original paragraph.") + p("Document reference 123") + styled_run_p("DocID", "Inserted bold red run"),
      CHAR_DOCID)

write("reverse_left.docx", p("The original paragraph.") + styled_run_p("DocID", "Kept bold red run"), CHAR_DOCID)
write("reverse_right.docx",
      p("The original paragraph.") + p("Kept bold red run") + p("Inserted small paragraph", '<w:pPr><w:pStyle w:val="DocID"/></w:pPr>'),
      PARA_DOCID)

print("wrote fixture pairs to", OUT)
