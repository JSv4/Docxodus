SYNTHETIC FIXTURES FOR DOCXODUS ISSUE #1189
https://github.com/JSv4/Docxodus/issues/1189

These packages were authored programmatically from literal OOXML using invented
Juniper/Elm labels and generic revision authors. They contain no customer documents,
embedded media/objects, macros, or external relationships. manifest.json records
each file hash, text inventory, and purpose. No Word diagnostic outputs are included.

Prioritize i1189-math-nested.docx. The four canonical custom XML/simple math controls
currently pass both bulk directions in Docxodus and match RevisionProcessor. These are
synthetic reprobes, not recovered original documents from the issue report.

DESKTOP WORD CAPTURE PROCEDURE

Keep each original input unchanged. For each case, make three independent copies:
1. Open in Word and save without accepting or rejecting revisions: NAME.opened.docx.
2. Reopen the original, use Review > Accept > Accept All Changes, then save as NAME.accepted.docx.
3. Reopen the original, use Review > Reject > Reject All Changes, then save as NAME.rejected.docx.

Wait until saving completes, then close and reopen the saved copies to confirm persistence.
Record Word version/build, operating system, and any repair prompt. Return native DOCX files.
Screenshots or PDFs cannot establish whether the underlying revision markers were resolved.
The ordinary text insertion controls, where present, should remain as untracked text on
acceptance and disappear on rejection. They confirm that the command took effect.

Do not infer intended math/table behavior if the special revision markers remain unchanged.
Word Online left the tested nested math and table-cell revisions unresolved even when it
resolved ordinary text revisions. Desktop behavior still needs to be established.
